# TechEats_Online-Food-Ordering-System
The TechEats Online food ordering system that I am proposing here, greatly simplifies the ordering process for both the Foodie and the Web Application.
System presents an interactive and up-to-date menu with all available options in an easy to use manner.Foodie can choose one or more items to place an order which will land in the payment. 
Foodie can view all the order details in the cart before checking out. At the end,Foodie  gets order confirmation details. Once the order is placed it is entered in the database and retrieved in pretty much real time. This allows Meal Employees to quickly go through the orders as they are received and process all orders efficiently.
